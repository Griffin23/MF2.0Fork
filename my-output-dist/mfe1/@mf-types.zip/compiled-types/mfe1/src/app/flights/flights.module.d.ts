export declare class FlightsModule {
}
