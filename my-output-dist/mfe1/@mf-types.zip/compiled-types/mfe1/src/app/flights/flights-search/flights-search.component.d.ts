export declare class FlightsSearchComponent {
    search(): void;
    terms(): void;
}
