import { Routes } from '@angular/router';
export declare const FLIGHTS_ROUTES: Routes;
