export * from './compiled-types/mfe1/src/app/flights/flights.module';
export { default } from './compiled-types/mfe1/src/app/flights/flights.module';